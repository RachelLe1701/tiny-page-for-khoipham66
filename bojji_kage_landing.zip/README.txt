Open index.html in any browser to preview.
To publish free: create a GitHub repository, upload index.html, then Settings > Pages > Deploy from branch > main.
